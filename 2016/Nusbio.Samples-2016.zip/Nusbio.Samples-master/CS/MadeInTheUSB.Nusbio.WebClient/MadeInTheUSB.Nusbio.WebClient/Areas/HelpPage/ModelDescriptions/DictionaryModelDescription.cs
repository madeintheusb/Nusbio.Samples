namespace MadeInTheUSB.NusbioDevice.WebClient.Areas.HelpPage.ModelDescriptions
{
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}